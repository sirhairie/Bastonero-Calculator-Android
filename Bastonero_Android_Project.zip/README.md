# Bastonero Calculator - Android

Android APK wrapper for Bastonero Calculator v29.

- Offline WebView app
- Preserves the existing HTML/CSS/JavaScript scoring interface
- Uses persistent WebView `localStorage`
- Save Result opens the Android file picker and saves the generated PNG
- Package: `com.bastonero.calculator`
- Minimum Android: Android 7.0 (API 24)

## Automatic APK
Every push to `main` runs **Build Bastonero APK** in GitHub Actions and uploads the APK as the `Bastonero-Calculator-APK` workflow artifact.
